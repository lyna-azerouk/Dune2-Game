
Pour lancer  :

```
$ stack build 
```
pour tests:
```
$ stack test
 ```


